package stepDefinitions;

public class Constants {

	
    public static final String URL = "https://demoqa.com/automation-practice-form";
    public static final String Path_TestData = ".\\src\\test\\test-data"; 
    public static final String File_TestData = "\\CustomerData.xls";
   // public static final String File_TestData2 = "Databasee.xlsx";
}
